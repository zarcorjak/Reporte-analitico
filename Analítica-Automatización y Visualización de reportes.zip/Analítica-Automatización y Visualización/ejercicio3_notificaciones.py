import smtplib
import pandas as pd
import os
import sys
from email.mime.multipart import MIMEMultipart
from email.mime.text  import MIMEText
from datetime import datetime
import logging



# LOGGING

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('notificaciones_controles.log', encoding='utf-8')
    ]
)
log = logging.getLogger(__name__)




CONFIG = {
    
    'MODO_DEMO':    True,
    'SMTP_HOST':    os.getenv('SMTP_HOST',    'smtp.gmail.com'),
    'SMTP_PORT':    int(os.getenv('SMTP_PORT', 587)),
    'SMTP_USER':    os.getenv('SMTP_USER',    'gestion.controles@empresa.com.co'),
    'SMTP_PASS':    os.getenv('SMTP_PASS',    'CONTRASEÑA_AQUI'),

    # Remitente que aparece en el correo
    'REMITENTE':    'Equipo Auditoría Interna <gestion.controles@empresa.com.co>',

    # CC siempre a auditoría
    'CC_AUDITORIA': 'auditoria.interna@empresa.com.co',
}

RUTA_BASE   = os.path.dirname(os.path.abspath(__file__))
BASE_MAESTRA = os.path.join(RUTA_BASE, 'Base_Maestra_Controles.xlsx')



# PLANTILLA DE CORREO HTML


def construir_cuerpo_html(control: dict) -> str:
    """Genera el cuerpo HTML del correo de notificación."""
    fecha_envio = datetime.now().strftime('%d de %B de %Y')
    color_nivel = {
        'Alto':   '#C0392B',
        'Medio':  '#E67E22',
        'Bajo':   '#F39C12',
    }.get(control.get('Complejidad_Evaluacion', ''), '#888888')

    return f"""
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <style>
    body       {{ font-family: Calibri, Arial, sans-serif; margin: 0; padding: 0; background: #f4f4f4; color: #333; }}
    .container {{ max-width: 680px; margin: 30px auto; background: #fff; border-radius: 8px;
                  box-shadow: 0 2px 10px rgba(0,0,0,0.1); overflow: hidden; }}
    .header    {{ background: #1F3864; padding: 28px 30px; text-align: center; }}
    .header h1 {{ color: #fff; margin: 0; font-size: 20px; letter-spacing: 0.5px; }}
    .header p  {{ color: #a8c4e0; margin: 6px 0 0; font-size: 13px; }}
    .alerta    {{ background: #FDEDEC; border-left: 5px solid #C0392B;
                  padding: 14px 20px; margin: 24px 30px 0; border-radius: 4px; }}
    .alerta p  {{ margin: 0; font-size: 14px; color: #922B21; font-weight: bold; }}
    .body      {{ padding: 20px 30px; }}
    .intro     {{ font-size: 14.5px; line-height: 1.7; margin-bottom: 20px; }}
    table      {{ width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 13.5px; }}
    th         {{ background: #1F3864; color: #fff; padding: 10px 14px; text-align: left; }}
    td         {{ padding: 9px 14px; border-bottom: 1px solid #eee; vertical-align: top; }}
    tr:nth-child(even) td {{ background: #f9f9f9; }}
    .badge     {{ display: inline-block; padding: 3px 10px; border-radius: 12px;
                  font-size: 12px; font-weight: bold; color: #fff;
                  background: {color_nivel}; }}
    .accion    {{ background: #EBF5FB; border: 1px solid #AED6F1; border-radius: 6px;
                  padding: 16px 20px; margin-bottom: 20px; }}
    .accion h3 {{ color: #1A5276; margin: 0 0 10px; font-size: 14px; }}
    .accion ul {{ margin: 0; padding-left: 20px; font-size: 13.5px; line-height: 1.8; }}
    .footer    {{ background: #f0f0f0; padding: 16px 30px; font-size: 12px; color: #777;
                  border-top: 1px solid #ddd; }}
    .footer a  {{ color: #1F3864; }}
  </style>
</head>
<body>
<div class="container">

  <div class="header">
    <h1>⚠️ Alerta — Control Inefectivo</h1>
    <p>Sistema de Gestión de Controles SOX | {fecha_envio}</p>
  </div>

  <div class="alerta">
    <p> Se ha identificado un control con resultado INEFECTIVO que requiere atención inmediata.</p>
  </div>

  <div class="body">
    <p class="intro">
      Estimado(a) <strong>{control.get('Responsable', 'Responsable')}</strong>,<br><br>
      Por medio del presente correo le informamos que durante la ejecución de las pruebas de
      efectividad del programa SOX se identificó que el control bajo su responsabilidad
      no superó la evaluación. A continuación, el detalle del hallazgo:
    </p>

    <table>
      <tr><th colspan="2"> Información del Control</th></tr>
      <tr><td><strong>ID del Control</strong></td>    <td>{control.get('ID_Control', '—')}</td></tr>
      <tr><td><strong>Nombre del Control</strong></td><td>{control.get('Nombre_Control', '—')}</td></tr>
      <tr><td><strong>Proceso</strong></td>           <td>{control.get('Nombre_Proceso', '—')}</td></tr>
      <tr><td><strong>ID del Proceso</strong></td>    <td>{control.get('ID_Proceso', '—')}</td></tr>
    </table>

    <table>
      <tr><th colspan="2"> Resultado de la Prueba</th></tr>
      <tr><td><strong>Resultado</strong></td>
          <td><span style="color:#C0392B;font-weight:bold;">Inefectivo</span></td></tr>
      <tr><td><strong>Complejidad</strong></td>
          <td><span class="badge">{control.get('Complejidad_Evaluacion', 'N/A')}</span></td></tr>
      <tr><td><strong>Causa raíz identificada</strong></td>
          <td>{control.get('Causa_Raiz_Limpia', '—')}</td></tr>
    </table>

    <div class="accion">
      <h3> Acciones Requeridas</h3>
      <ul>
        <li>Elaborar un <strong>Plan de Acción formal</strong> en un plazo máximo de <strong>10 días hábiles</strong>.</li>
        <li>El plan debe incluir: causa raíz detallada, acción correctiva, responsable y fecha comprometida.</li>
        <li>Registrar el plan en la herramienta de seguimiento SOX / módulo de planes de acción.</li>
        <li>Enviar copia del plan al correo: <a href="mailto:auditoria.interna@empresa.com.co">auditoria.interna@empresa.com.co</a></li>
      </ul>
    </div>

    <p style="font-size:13.5px; line-height:1.7;">
      Para más información sobre el hallazgo o si requiere soporte en la elaboración del plan de acción,
      comuníquese con el equipo de Auditoría Interna.<br><br>
      Este es un mensaje generado automáticamente. Por favor no responder directamente a este correo.
    </p>
  </div>

  <div class="footer">
    Generado automáticamente por el Sistema de Gestión de Controles SOX &nbsp;|&nbsp;
    Auditoría Interna — Empresa Colombia &nbsp;|&nbsp;
    <a href="mailto:auditoria.interna@empresa.com.co">auditoria.interna@empresa.com.co</a>
  </div>

</div>
</body>
</html>
""".strip()




def cargar_inefectivos() -> pd.DataFrame:
    """Lee la hoja de controles inefectivos desde la Base Maestra."""
    if not os.path.exists(BASE_MAESTRA):
        log.error(f"No se encontró el archivo: {BASE_MAESTRA}")
        log.error("Ejecute primero el script ejercicio1_etl.py para generar la Base Maestra.")
        sys.exit(1)

    df = pd.read_excel(BASE_MAESTRA, sheet_name='06_Controles_Inefectivos', skiprows=1)
    df.columns = df.columns.str.strip()
    # Eliminar fila de encabezado duplicado si existe
    df = df[df['ID_Control'].notna() & (df['ID_Control'] != 'ID_Control')]
    log.info(f"{len(df)} control(es) inefectivo(s) cargado(s) desde Base Maestra.")
    return df


def enviar_correo(destinatario: str, asunto: str, cuerpo_html: str, control_id: str):
    """Envía el correo vía SMTP. En modo DEMO solo imprime el contenido."""
    if CONFIG['MODO_DEMO']:
        print("\n" + "─" * 60)
        print(f"  [DEMO] CORREO QUE SE ENVIARÍA")
        print(f"  Para    : {destinatario}")
        print(f"  CC      : {CONFIG['CC_AUDITORIA']}")
        print(f"  Asunto  : {asunto}")
        print(f"  Control : {control_id}")
        print("─" * 60)
        return True

    try:
        msg = MIMEMultipart('alternative')
        msg['From']    = CONFIG['REMITENTE']
        msg['To']      = destinatario
        msg['Cc']      = CONFIG['CC_AUDITORIA']
        msg['Subject'] = asunto

        msg.attach(MIMEText(cuerpo_html, 'html', 'utf-8'))

        with smtplib.SMTP(CONFIG['SMTP_HOST'], CONFIG['SMTP_PORT']) as servidor:
            servidor.ehlo()
            servidor.starttls()
            servidor.login(CONFIG['SMTP_USER'], CONFIG['SMTP_PASS'])
            destinatarios = [destinatario, CONFIG['CC_AUDITORIA']]
            servidor.sendmail(CONFIG['SMTP_USER'], destinatarios, msg.as_string())

        log.info(f"✓ Correo enviado a {destinatario} | Control: {control_id}")
        return True

    except smtplib.SMTPAuthenticationError:
        log.error("Error de autenticación SMTP. Revise SMTP_USER y SMTP_PASS.")
        return False
    except smtplib.SMTPConnectError:
        log.error(f"No se pudo conectar a {CONFIG['SMTP_HOST']}:{CONFIG['SMTP_PORT']}.")
        return False
    except Exception as e:
        log.error(f"Error inesperado enviando correo a {destinatario}: {e}")
        return False


def procesar_notificaciones():
    """Flujo principal: carga inefectivos y dispara notificaciones."""
    print("=" * 65)
    print("   AUTOMATIZACIÓN DE NOTIFICACIONES — CONTROLES INEFECTIVOS")
    print(f"   Ejecución: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"   Modo: {'DEMO (sin envío real)' if CONFIG['MODO_DEMO'] else 'PRODUCCIÓN (envío real)'}")
    print("=" * 65)

    df_inefectivos = cargar_inefectivos()

    if df_inefectivos.empty:
        log.info("No hay controles inefectivos pendientes de notificación. Proceso finalizado.")
        return

    enviados   = 0
    fallidos   = 0
    procesados = []

    for _, fila in df_inefectivos.iterrows():
        control = fila.to_dict()
        control_id  = str(control.get('ID_Control', 'N/A'))
        responsable = str(control.get('Responsable', 'Sin asignar'))
        email       = str(control.get('Email_Responsable', ''))
        nombre_ctrl = str(control.get('Nombre_Control', '—'))

        if not email or email in ('nan', 'Sin asignar', ''):
            log.warning(f"Control {control_id} sin correo de responsable — omitido.")
            continue

        asunto = (
            f"[ACCIÓN REQUERIDA] Control Inefectivo — {control_id} | "
            f"Plan de acción en 10 días hábiles"
        )
        cuerpo = construir_cuerpo_html(control)

        log.info(f"Procesando control {control_id} → {responsable} ({email})")
        exito = enviar_correo(email, asunto, cuerpo, control_id)

        if exito:
            enviados += 1
        else:
            fallidos += 1

        procesados.append({
            'ID_Control':       control_id,
            'Responsable':      responsable,
            'Email':            email,
            'Nombre_Control':   nombre_ctrl,
            'Estado_Envio':     'Enviado' if exito else 'Fallido',
            'Timestamp':        datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        })

    # Reporte final
    print("\n" + "=" * 65)
    print(f"   RESUMEN DE NOTIFICACIONES")
    print(f"   Total controles inefectivos : {len(df_inefectivos)}")
    print(f"   Notificaciones enviadas     : {enviados}")
    print(f"   Notificaciones fallidas     : {fallidos}")
    print("=" * 65)

    # Guardar log de envíos en Excel
    if procesados:
        df_log = pd.DataFrame(procesados)
        log_file = os.path.join(RUTA_BASE, 'log_notificaciones.xlsx')
        df_log.to_excel(log_file, index=False)
        log.info(f"Registro de envíos guardado en: {log_file}")



# PUNTO DE ENTRADA

if __name__ == '__main__':
    procesar_notificaciones()
