import pandas as pd
import numpy as np
from datetime import datetime
import warnings
import os


warnings.filterwarnings('ignore')


RUTA_BASE = os.path.dirname(os.path.abspath(__file__))
ARCHIVO_ORIGEN = os.path.join(RUTA_BASE, 'Base para prueba tecnica - Analista gestion de información.xlsx')
ARCHIVO_SALIDA = os.path.join(RUTA_BASE, 'Base_Maestra_Controles.xlsx')

RESPONSABLES = {
    
    '120589':  ('Laura Martínez',      'l.martinez@empresa.com.co'),
    '120594':  ('Carlos Ríos',         'c.rios@empresa.com.co'),
    '124270':  ('Diana Ospina',        'd.ospina@empresa.com.co'),
    '127521':  ('Andrés Gómez',        'a.gomez@empresa.com.co'),
    '127524':  ('Andrés Gómez',        'a.gomez@empresa.com.co'),
    '143716':  ('Felipe Herrera',      'f.herrera@empresa.com.co'),
    '208231':  ('Camila Vargas',       'c.vargas@empresa.com.co'),
    '283724':  ('Jorge Salcedo',       'j.salcedo@empresa.com.co'),
    '283743':  ('Jorge Salcedo',       'j.salcedo@empresa.com.co'),
    '321412':  ('Natalia Restrepo',    'n.restrepo@empresa.com.co'),
    '321413':  ('Natalia Restrepo',    'n.restrepo@empresa.com.co'),
    '323531':  ('Mauricio Patiño',     'm.patino@empresa.com.co'),
    '330824':  ('Sandra Londoño',      's.londono@empresa.com.co'),
    '333227':  ('Ricardo Cano',        'r.cano@empresa.com.co'),
    '335644':  ('Paola Jiménez',       'p.jimenez@empresa.com.co'),
    '335880':  ('David Arango',        'd.arango@empresa.com.co'),
    '335881':  ('David Arango',        'd.arango@empresa.com.co'),
    '378037':  ('Sofía Cardona',       's.cardona@empresa.com.co'),
    '378047':  ('Sofía Cardona',       's.cardona@empresa.com.co'),
    '380669':  ('Valentina Cruz',      'v.cruz@empresa.com.co'),
    '382160':  ('Sebastián Torres',    's.torres@empresa.com.co'),
    '383670':  ('Isabella Morales',    'i.morales@empresa.com.co'),
    '89084':   ('Tomás Bermúdez',      't.bermudez@empresa.com.co'),
    '89089':   ('Tomás Bermúdez',      't.bermudez@empresa.com.co'),
    '95753':   ('Luisa Fernanda Ruiz', 'lf.ruiz@empresa.com.co'),
    '97193':   ('Andrés Peñaloza',     'a.penaloza@empresa.com.co'),
    '97196':   ('Andrés Peñaloza',     'a.penaloza@empresa.com.co'),
    '97200':   ('María Alejandra Gil', 'ma.gil@empresa.com.co'),
    '97207':   ('Hernando Vásquez',    'h.vasquez@empresa.com.co'),
    '97210':   ('Hernando Vásquez',    'h.vasquez@empresa.com.co'),
    'C-100164':('Ana Milena López',    'am.lopez@empresa.com.co'),
}

print("=" * 65)
print("   CONSTRUCCIÓN DE BASE MAESTRA — CONTROLES SOX")
print(f"   Ejecución: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
print("=" * 65)



#CARGA DE DATOS  


print("\n[1/5] Cargando hojas del archivo fuente...")

df_controles = pd.read_excel(ARCHIVO_ORIGEN, sheet_name='Riesgos y controles',    dtype=str)
df_resultados = pd.read_excel(ARCHIVO_ORIGEN, sheet_name='Resultados pruebas',    dtype=str)
df_estructura = pd.read_excel(ARCHIVO_ORIGEN, sheet_name='Estructura org',        dtype=str)

print(f"   ✓ Riesgos y controles   : {len(df_controles)} registros")
print(f"   ✓ Resultados de pruebas : {len(df_resultados)} registros")
print(f"   ✓ Estructura org        : {len(df_estructura)} registros")



print("\n[2/5] Limpiando y estandarizando campos...")

#Renombrado de columnas
df_controles.columns = [
    'Pais',
    'ID_Proceso',
    'Nombre_Proceso',
    'ID_Riesgo',
    'ID_Control',
    'Nombre_Control',
    'Categorias_Control',
    'Frecuencia',
    'Naturaleza',
    'Nivel_Automatizacion'
]

df_resultados.columns = [
    'Pais',
    'ID_Prueba_Raw',
    'ID_Control',
    'Fecha_Inicio',
    'Fecha_Fin',
    'Conclusion',
    'Complejidad_Evaluacion',
    'Causa_Raiz'
]

# La tercera hoja tiene una columna duplicada sin nombre → se elimina
df_estructura = df_estructura.drop(columns=[df_estructura.columns[2]])
df_estructura.columns = [
    'Pais',
    'ID_Proceso',
    'Tipo_Proceso',
    'Estado_Proceso',
    'Comite',
    'Gerencia'
]


for df in [df_controles, df_resultados, df_estructura]:
    for col in df.select_dtypes(include='object').columns:
        df[col] = df[col].str.strip()

# Reemplazar "nan" string y vacíos por NaN real
for df in [df_controles, df_resultados, df_estructura]:
    df.replace({'nan': np.nan, 'None': np.nan, '': np.nan}, inplace=True)


df_resultados['Fecha_Inicio'] = pd.to_datetime(df_resultados['Fecha_Inicio'], errors='coerce')
df_resultados['Fecha_Fin']    = pd.to_datetime(df_resultados['Fecha_Fin'],    errors='coerce')


df_resultados['Anio_Prueba'] = (
    df_resultados['ID_Prueba_Raw']
    .str.extract(r'(\d{4})$')
    .astype('Int64')
)


df_resultados['Conclusion_Std'] = df_resultados['Conclusion'].map({
    '5 - Efectivo':   'Efectivo',
    '6 - Inefectivo': 'Inefectivo',
}).fillna('Pendiente')


df_resultados['Dias_Prueba'] = (
    (df_resultados['Fecha_Fin'] - df_resultados['Fecha_Inicio'])
    .dt.days
    .abs()
    .fillna(0)
    .astype(int)
)


df_resultados['Complejidad_Evaluacion'] = df_resultados['Complejidad_Evaluacion'].fillna('Sin clasificar')

print("   ✓ Columnas renombradas y tipos de datos corregidos")
print(f"   ✓ Conclusiones únicas: {df_resultados['Conclusion_Std'].unique()}")



print("\n[3/5] Integrando estructura organizacional...")

df_controles_org = df_controles.merge(
    df_estructura[['ID_Proceso', 'Comite', 'Gerencia', 'Estado_Proceso']],
    on='ID_Proceso',
    how='left'
)


df_controles_org['Comite_Limpio']   = df_controles_org['Comite'].str.replace('Colombia-', '', regex=False)
df_controles_org['Gerencia_Limpia'] = df_controles_org['Gerencia'].str.replace('Colombia-', '', regex=False)

print(f"   ✓ Procesos con estructura org encontrada: {df_controles_org['Comite'].notna().sum()} / {len(df_controles_org)}")



print("\n[4/5] Consolidando resultados de pruebas por control...")


df_res_reciente = (
    df_resultados
    .sort_values('Fecha_Fin', ascending=False, na_position='last')
    .drop_duplicates(subset='ID_Control', keep='first')
    [['ID_Control', 'Conclusion', 'Conclusion_Std', 'Complejidad_Evaluacion',
      'Causa_Raiz', 'Fecha_Inicio', 'Fecha_Fin', 'Anio_Prueba', 'Dias_Prueba']]
)

# Join principal: controles + org + resultado
df_maestro = df_controles_org.merge(
    df_res_reciente,
    on='ID_Control',
    how='left'
)


df_maestro['Conclusion_Std'] = df_maestro['Conclusion_Std'].fillna('Sin resultado')

print(f"   ✓ Registros en base maestra          : {len(df_maestro)}")
print(f"   ✓ Controles con resultado             : {df_maestro['Conclusion_Std'].ne('Sin resultado').sum()}")
print(f"   ✓ Controles sin resultado registrado  : {df_maestro['Conclusion_Std'].eq('Sin resultado').sum()}")



print("\n[5/5] Calculando campos derivados y asignando responsables...")

# Agregar responsable desde el catálogo
df_maestro['Responsable']      = df_maestro['ID_Control'].map(lambda x: RESPONSABLES.get(str(x), ('Sin asignar', 'sin.asignar@empresa.com.co'))[0])
df_maestro['Email_Responsable'] = df_maestro['ID_Control'].map(lambda x: RESPONSABLES.get(str(x), ('Sin asignar', 'sin.asignar@empresa.com.co'))[1])

# Semáforo de riesgo visual
def semaforo(row):
    if row['Conclusion_Std'] == 'Inefectivo':
        comp = str(row.get('Complejidad_Evaluacion', '')).lower()
        if 'alto' in comp:
            return 'ROJO CRÍTICO'
        return 'ROJO'
    elif row['Conclusion_Std'] == 'Efectivo':
        return 'VERDE'
    elif row['Conclusion_Std'] == 'Sin resultado':
        return 'GRIS'
    return 'AMARILLO'

df_maestro['Semaforo'] = df_maestro.apply(semaforo, axis=1)

# Clasificación de automatización simplificada
mapa_auto = {
    'Automático':               'Alto',
    'Semiautomático':           'Medio',
    'Manual dependiente de TI': 'Bajo',
    'Manual independiente':     'Bajo',
}
df_maestro['Nivel_Auto_Simplificado'] = df_maestro['Nivel_Automatizacion'].map(mapa_auto).fillna('N/A')

# Año de prueba
df_maestro['Anio_Prueba'] = df_maestro['Anio_Prueba'].fillna(0).astype(int)


controles_freq = df_maestro.groupby('ID_Control')['ID_Riesgo'].nunique().rename('Num_Riesgos_Cubiertos')
df_maestro = df_maestro.merge(controles_freq, on='ID_Control', how='left')
df_maestro['Control_Clave'] = df_maestro['Num_Riesgos_Cubiertos'].apply(lambda x: 'Sí' if x >= 2 else 'No')


df_maestro['Causa_Raiz'] = df_maestro['Causa_Raiz'].fillna('—')
df_maestro['Causa_Raiz_Limpia'] = (
    df_maestro['Causa_Raiz']
    .str.replace('CIRF: EO - ', '', regex=False)
    .str.replace('CIRF: DI - ', '', regex=False)
    .str.strip()
)

print(f"   ✓ Campos derivados calculados: Semáforo, Nivel_Auto, Control_Clave")
print(f"   ✓ Responsables asignados: {df_maestro['Responsable'].ne('Sin asignar').sum()} / {len(df_maestro)}")



resumen_proceso = (
    df_maestro
    .drop_duplicates(subset='ID_Control')
    .groupby(['ID_Proceso', 'Nombre_Proceso', 'Comite_Limpio', 'Gerencia_Limpia'])
    .agg(
        Total_Controles=('ID_Control', 'count'),
        Controles_Efectivos=('Conclusion_Std', lambda x: (x == 'Efectivo').sum()),
        Controles_Inefectivos=('Conclusion_Std', lambda x: (x == 'Inefectivo').sum()),
        Controles_Sin_Resultado=('Conclusion_Std', lambda x: (x == 'Sin resultado').sum()),
        Controles_Clave=('Control_Clave', lambda x: (x == 'Sí').sum()),
    )
    .reset_index()
)
resumen_proceso['Tasa_Efectividad_%'] = (
    resumen_proceso['Controles_Efectivos'] / resumen_proceso['Total_Controles'] * 100
).round(1)
resumen_proceso['Exposicion_Riesgo'] = resumen_proceso.apply(
    lambda r: 'Alta' if r['Controles_Inefectivos'] > 0 else ('Media' if r['Controles_Sin_Resultado'] > 1 else 'Baja'),
    axis=1
)
resumen_proceso = resumen_proceso.sort_values('Tasa_Efectividad_%', ascending=True)


inefectivos = df_maestro[df_maestro['Conclusion_Std'] == 'Inefectivo'].drop_duplicates(subset='ID_Control')[[
    'ID_Control', 'Nombre_Control', 'ID_Proceso', 'Nombre_Proceso',
    'Conclusion_Std', 'Complejidad_Evaluacion', 'Causa_Raiz_Limpia',
    'Responsable', 'Email_Responsable', 'Semaforo'
]]


# EXPORTAR A EXCEL

print(f"\n Exportando a: {ARCHIVO_SALIDA}")

ORDEN_COLUMNAS_MAESTRA = [
    'Pais', 'ID_Proceso', 'Nombre_Proceso', 'Comite_Limpio', 'Gerencia_Limpia',
    'ID_Riesgo', 'ID_Control', 'Nombre_Control', 'Categorias_Control',
    'Frecuencia', 'Naturaleza', 'Nivel_Automatizacion', 'Nivel_Auto_Simplificado',
    'Control_Clave', 'Num_Riesgos_Cubiertos',
    'Conclusion', 'Conclusion_Std', 'Semaforo',
    'Complejidad_Evaluacion', 'Causa_Raiz_Limpia',
    'Fecha_Inicio', 'Fecha_Fin', 'Anio_Prueba', 'Dias_Prueba',
    'Responsable', 'Email_Responsable',
]

with pd.ExcelWriter(ARCHIVO_SALIDA, engine='xlsxwriter', datetime_format='dd/mm/yyyy') as writer:

    wb_out = writer.book

    
    fmt_header = wb_out.add_format({
        'bold': True, 'font_color': 'white', 'bg_color': '#1F3864',
        'border': 1, 'align': 'center', 'valign': 'vcenter', 'text_wrap': True
    })
    fmt_verde   = wb_out.add_format({'bg_color': '#C6EFCE', 'font_color': '#276221', 'border': 1})
    fmt_rojo    = wb_out.add_format({'bg_color': '#FFC7CE', 'font_color': '#9C0006', 'border': 1})
    fmt_gris    = wb_out.add_format({'bg_color': '#EEEEEE', 'font_color': '#666666', 'border': 1})
    fmt_normal  = wb_out.add_format({'border': 1, 'valign': 'vcenter'})
    fmt_titulo  = wb_out.add_format({'bold': True, 'font_size': 14, 'font_color': '#1F3864'})

    def escribir_hoja(df, nombre, col_semaforo=None):
        df.to_excel(writer, sheet_name=nombre, index=False, startrow=1)
        ws = writer.sheets[nombre]
        for c_idx, col in enumerate(df.columns):
            ws.write(1, c_idx, col, fmt_header)
            ws.set_column(c_idx, c_idx, max(len(col) + 2, 14))
        ws.set_row(1, 30)
        ws.write(0, 0, f'📋 {nombre}  |  Generado: {datetime.now().strftime("%d/%m/%Y %H:%M")}', fmt_titulo)
        # Formato condicional por semáforo
        if col_semaforo and col_semaforo in df.columns:
            col_idx = list(df.columns).index(col_semaforo)
            for row_i, val in enumerate(df[col_semaforo], start=2):
                fmt = fmt_verde if val == 'VERDE' else (fmt_rojo if 'ROJO' in str(val) else fmt_gris)
                ws.write(row_i, col_idx, val, fmt)

    # Controles
    escribir_hoja(df_controles, '01_Controles_Original')

    #Resultados
    df_res_export = df_resultados.copy()
    escribir_hoja(df_res_export, '02_Resultados_Original')

    #Estructura
    escribir_hoja(df_estructura, '03_Estructura_Org')

    #BASE MAESTRA
    cols_disponibles = [c for c in ORDEN_COLUMNAS_MAESTRA if c in df_maestro.columns]
    escribir_hoja(df_maestro[cols_disponibles], '04_Base_Maestra', col_semaforo='Semaforo')

    #Resumen por proceso
    escribir_hoja(resumen_proceso, '05_Resumen_Proceso')

    #Controles inefectivos
    escribir_hoja(inefectivos, '06_Controles_Inefectivos', col_semaforo='Semaforo')

print("\n" + "=" * 65)
print("   PROCESO COMPLETADO EXITOSAMENTE")
print(f"   Base Maestra: {len(df_maestro)} registros | {len(df_maestro.columns)} columnas")
print(f"   Inefectivos encontrados: {len(inefectivos)}")
print(f"   Archivo generado: {ARCHIVO_SALIDA}")
print("=" * 65)
